import React, { Component } from "react";
import images from "../images.jfif";
import homeemoji from "../homeemoji.jfif";

class Home extends Component {
  constructor() {
    super();
    this.state = {
      fields: {},

      userAuth: false
    };
  }
  render() {
    const username = localStorage.getItem("username");
    
   if (localStorage.getItem("authenticate")) {
      return (
        <div className=" ">
          <header>
            Hello, <strong>{username}</strong>
            <img src={homeemoji} alt="logo" />
          </header>
        </div>
      );
    } else {
      return (
        <div>
          <header>
            <img src={images} className="App-logo" alt="logo" />
          </header>
        </div>
      );
    }
  }
}

export default Home;
