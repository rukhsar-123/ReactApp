import React, { Component } from 'react';
import './App.css';
import RouteFile  from './Components/RouteFile';

class App extends Component {
  
  render() {
    return (
    
       < RouteFile/>
     
     
    );
  }
}

export default App;
