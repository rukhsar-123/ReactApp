import React, { Component } from "react";
import { BrowserRouter, Route, Link } from "react-router-dom";
import Home from "./Home";
import RegisterForm from "./RegisterForm";
import SigninForm from "./SigninForm";
import Logout from "./Logout";

class RouteFile extends Component {
 
  render() {
    return (
      <div>
        <BrowserRouter>
          <div>
            <div className="FormCenter">
              <div className="PageSwitcher">
                <Link to="/home" className="PageSwitcher__Item">Home</Link>
                <Link to="/register" className="PageSwitcher__Item">Register</Link>
                <Link to="/singin" className="PageSwitcher__Item">Singin</Link>
                <Link to="/logout" className="PageSwitcher__Item">Logout</Link>
              </div>
            </div>
            <Route path="/home" component={Home} />
            <Route path="/register" component={RegisterForm} />
            <Route path="/singin" component={SigninForm}   />
            <Route path="/logout" component={Logout} />
          </div>
        </BrowserRouter>
      </div>
    );
  }
}

export default RouteFile;
