import React from "react";
import { Redirect } from "react-router-dom";

class SigninForm extends React.Component {
  constructor() {
    super();
    this.state = {
      fields: {},
      errors: {},
      userAuth: false
    };

    this.handleChange = this.handleChange.bind(this);
    this.submituserSignin = this.submituserSignin.bind(this);
  }

  handleChange(e) {
    let fields = this.state.fields;
    fields[e.target.name] = e.target.value;
    this.setState({
      fields
    });
  }

  submituserSignin(e) {
    e.preventDefault();
    if (this.validateForm()) {
      let fields = {};
      fields["username"] = "";
      fields["password"] = "";
      this.setState({ fields: fields });

      console.log(localStorage.getItem("username"));

      console.log(localStorage.getItem("password"));
    
      if (
        this.state.fields.username === localStorage.getItem("username") &&
        this.state.fields.password === localStorage.getItem("password")
      ) {
        localStorage.setItem('authenticate', true)
        this.setState({ userAuth: true });
        alert("logged In");
    } else {
        alert("Wrong login credentials.");
      }

     
    }
  }

  validateForm() {
    let fields = this.state.fields;
    let errors = {};
    let formIsValid = true;

    if (!fields["username"]) {
      formIsValid = false;
      errors["username"] = "*Please enter your username.";
    }

    if (typeof fields["username"] !== "undefined") {
      if (!fields["username"].match(/^[a-zA-Z ]*$/)) {
        formIsValid = false;
        errors["username"] = "*Please enter alphabet characters only.";
      }
    }
    if (!fields["password"]) {
      formIsValid = false;
      errors["password"] = "*Please enter your password.";
    }

    if (typeof fields["password"] !== "undefined") {
      if (
        !fields["password"].match(
          /^.*(?=.{8,})(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%&]).*$/
        )
      ) {
        formIsValid = false;
        errors["password"] = "*Please enter secure and strong password.";
      }
    }

    this.setState({
      errors: errors
    });
    return formIsValid;
  }

  render() {
    if (this.state.userAuth) {
      return <Redirect to={"/Home"} />;
    }
    return (
      <div id="main-registration-container">
        <div id="register">
          <h3>Singin page</h3>
          <form
            method="post"
            name="userSinginForm"
            onSubmit={this.submituserSignin}
          >
            <label>Name</label>
            <input
              type="text"
              className="FormField__Input"
              name="username"
              value={this.state.fields.username}
              onChange={this.handleChange}
            />
            <div className="errorMsg">{this.state.errors.username}</div>
            <label>Password</label>
            <input
              type="password"
              className="FormField__Input"
              name="password"
              value={this.state.fields.password}
              onChange={this.handleChange}
            />
            <div className="errorMsg">{this.state.errors.password}</div>
            <input type="submit" className="button" value="Sing in" />
          </form>
        </div>
      </div>
    );
  }
}

export default SigninForm;
