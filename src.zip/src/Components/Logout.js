import React, { Component } from "react";
import { Redirect } from "react-router-dom";
class Logout extends Component {
  
  render() {
    if (localStorage.getItem('authenticate')==='true') {
      localStorage.removeItem("userAuth");
      localStorage.removeItem("authenticate");
     
      return (<Redirect to={'/home'}/>)
     
    }
    return <span className="d-block pb-4 h2 text-dark border-bottom border-gray">Logout</span>;
  }
}



export default Logout;
